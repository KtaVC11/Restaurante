/**
 ** Add class to add overlay in quick view next/prev
 **/
/*
$(document).ready(function () {
    $('.xoo-cp-modal, .xoo-cp-opac, .xoo-qv-panel, .xoo-qv-opac').addClass('Fixed');
});
*/